function [clips,fs,num] = CutClips(filename)%下面为切片函数
    [x, fs]=audioread('selfdail.m4a');%录音文件
    n=length(x);
    num=0;
    ifront=0;
    limitx=20000;%看主要噪声长度
    limity=0.055;%看有效数值赋度的下限
    for i = 1:n-limitx
        j = 0;
        while j<limitx
            if abs(x(i+j))>limity
                if ifront==0
                    ifront = i+j;
                end
                break;
            end
            j = j + 1;
        end
        % 连续20000皆
        if j == limitx && ifront ~= 0   
            num = num + 1;
            clips{num, : } = x(ifront:i).';
            ifront = 0;
        end
    end
end