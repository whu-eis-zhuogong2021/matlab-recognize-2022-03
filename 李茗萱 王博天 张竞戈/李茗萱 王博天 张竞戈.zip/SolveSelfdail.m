matchnum = [941,1336;697,1209;697,1336;697,1477;770,1209;770,1336;770,1477;852 1209;852 1336;852 1477];%从0-9的频率
%录音文件 手机拨号结果应为12345678
%%
%读取音频文件
info =audioinfo('selfdail.m4a');%获取音频文件的信息
[x,fs] = audioread('selfdail.m4a');%读取音频文件
%sound(audio,Fs);%播放音频文件
audiolength = length(x);%获取音频文件的数据长度
t = 1:1:audiolength;
%%
%观察时间幅度图与切片
figure(1),
plot(t,x(1:audiolength));
xlabel('Time');
ylabel('Audio Signal');
title('原始音频文件信号幅度图');%原始时间幅度图,用于观察并调整切片函数的参数
[clips,fs,num] = CutClips('selfdail.m4a');%切片函数传值
%切片函数参数 limitx=20000,limity=0.055取法见函数

diff= 6;%允许的fft结果与matchnum之间的误差
%%
%fft 匹配全部在一个大循环
for i = 1:num%此处num为8，执行八次
    
    clip = cell2mat(clips(i));%将迭代后的多个矩阵合成为一个矩阵
    N=length(clip); %样点个数
    df=fs/(N-1);%分辨率
    f=(0:N-1)*df;%其中每点的频率
    Y=fft(clip(1:N))/N*2;
    [maxi] = Find2maxFreq(f(1:fix(N/2)),abs(Y(1:fix(N/2))));
    
    % 匹配 输出结果＋展示图像
    for j = 1:size(matchnum,1)
        if abs(maxi(1,1)-matchnum(j,1))<diff && abs(maxi(1,2)-matchnum(j,2))<diff
            fprintf("%d ",j-1)%输出读取的数字结果
        end
    end
       subplot(2,num,i*2-1);
       plot(clip);%画出切片结果
       subplot(2,num,i*2);
       plot(f(1:fix(N/2)),abs(Y(1:fix(N/2))));
       xlim([0,2500]);%画出频率图，限制频率范围，否则很丑
   
end



