function  maxi = Find2maxFreq(f,y)
    maxi = 0;
    for i = 2:length(y)-1
        if  y(i)>y(i-1) && y(i)>y(i+1) &&y(i)>0.01%简单粗暴，比周围大且不像干扰频率幅度那么小
            maxi = [maxi f(i)];
        end
    end
    maxi = maxi(2:length(maxi));%存两个最大频率
end